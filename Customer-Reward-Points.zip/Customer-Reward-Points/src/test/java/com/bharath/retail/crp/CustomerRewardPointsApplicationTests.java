package com.bharath.retail.crp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRewardPointsApplicationTests {

	@Test
	void contextLoads() {
	}

}
